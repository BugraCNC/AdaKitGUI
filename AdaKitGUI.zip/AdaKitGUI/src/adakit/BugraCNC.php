<?php

namespace adakit;

use pocketmine\plugin\PluginBase;
use pocketmine\utils\Config;
use pocketmine\{Player, Server};
use pocketmine\command\{Command, CommandSender};
use onebone\economyapi\EconomyAPI;
use pocketmine\item\Item;
use pocketmine\event\Listener;
use pocketmine\math\Vector3;
use korado531m7\InventoryMenuAPI\InventoryMenu;
use korado531m7\InventoryMenuAPI\event\InventoryClickEvent;
use korado531m7\InventoryMenuAPI\event\InventoryCloseEvent;
use korado531m7\InventoryMenuAPI\inventory\HopperInventory;
use korado531m7\InventoryMenuAPI\InventoryType;

class BugraCNC extends PluginBase implements Listener{

	public function onEnable(){
		$this->getServer()->getPluginManager()->registerEvents($this, $this);
		@mkdir($this->getDataFolder());
		$this->data = new Config($this->getDataFolder()."config.yml", Config::YAML);
		InventoryMenu::register($this);
	}

	public function onCommand(CommandSender $o, Command $kmt, string $label, array $args): bool{
		switch($kmt->getName()){
			case "adakit":
			$id = [2 => Item::get(4)->setCustomName("AdaKit")];
			$menu = new HopperInventory();
			$menu->setContents($id);
			$menu->setName("AdaKit Ekranı");
			$menu->send($o);
			break;
		}
		return true;
	}

	public function onClose(InventoryCloseEvent $e){
		// $e->setCancelled()
	}

	public function onClicked(InventoryClickEvent $e){
		$p = $e->getPlayer();
		$inv = $e->getInventory();
		$item = $e->getItem();
		$dat = $this->data->get($p->getName());
		switch($inv->getTitle()){
			case "AdaKit Ekranı":
			if($item->getCustomName("AdaKit")){
				if($dat["Baslangic"] >= $dat["Bitis"]){
					 $p->getInventory()->addItem(Item::get(4, 0, 50));
  	  $p->getInventory()->addItem(Item::get(2, 0, 124));
  $p->getInventory()->addItem(Item::get(17, 0, 16));
  $p->getInventory()->addItem(Item::get(391, 0, 16));
  $p->getInventory()->addItem(Item::get(81, 0, 5));
  	  $p->sendMessage("§cAda Kiti §7Envanterinize Eklendi!");
  	  $bugun = date("d.m.Y");
  	  $bitis = strtotime("1 years", strtotime($bugun));
      $bitis = date("d.m.Y", $bitis);
      $gelecek = strtotime('+1 years');
      $unix = $gelecek-time();
  	  $this->data->set($p->getName(), [
            "Alınan-Zaman" => $bugun,
            "Birdaha-Alıcagı-Zaman" => $bitis,
            "Unix-1" => time(),
            "Unix-2" => $unix
  	                                 ]);
  	  $this->data->save();
  	   }else{
      $p->sendMessage("Bu Komut Tek Seferlik.");
		   }
			}
			break;
		}
	}
}